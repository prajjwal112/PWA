import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'pwa';
 constructor(private readonly http: HttpClient){
}
  ngOnInit(){
    this.http.get('https://jsonplaceholder.typicode.com/posts/1').pipe(
      catchError((error:HttpErrorResponse)=>throwError(error))
    )
    .subscribe({
      next:(data)=>{
        console.log(data);
      }
    })
  }
}
